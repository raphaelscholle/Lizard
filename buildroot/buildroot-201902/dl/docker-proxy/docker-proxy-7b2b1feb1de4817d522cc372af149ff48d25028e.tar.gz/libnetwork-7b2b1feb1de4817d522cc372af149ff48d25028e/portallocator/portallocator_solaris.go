package portallocator

func getDynamicPortRange() (start int, end int, err error) {
	return 32768, 65535, nil
}
