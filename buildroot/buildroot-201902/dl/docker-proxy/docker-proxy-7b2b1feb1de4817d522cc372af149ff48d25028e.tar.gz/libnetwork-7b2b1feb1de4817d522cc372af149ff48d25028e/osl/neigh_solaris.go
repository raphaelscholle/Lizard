package osl

// NeighOption is a function option type to set interface options
type NeighOption func()
