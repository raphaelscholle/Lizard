/*
 * desktop_res_tw.h
 * big5 charset for Complex Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-02-03.
 */

#define MGDT_ST_ICONMENU        ""
#define MGDT_ST_OPEN            "���}"
#define MGDT_ST_ABOUT           "���_"
#define MGDT_ST_ABOUTM          "���_MiniGUI..."
#define MGDT_ST_REFRESH         "��s"
