#define progress_bar                 "Progress Bar"
#define calculating_please_waiting   "Calculating Pleas Wwaiting"
