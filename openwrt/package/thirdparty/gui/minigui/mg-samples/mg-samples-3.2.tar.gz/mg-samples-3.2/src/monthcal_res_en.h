#define ok_                                    "OK"
#define date_                                  "Date"
#define the_date_you_selected_is              "The date you selected is: %d.%d.%d"

