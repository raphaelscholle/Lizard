/*
 * bitblt_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define BB_ST_CAP   "Bitblt demo"
