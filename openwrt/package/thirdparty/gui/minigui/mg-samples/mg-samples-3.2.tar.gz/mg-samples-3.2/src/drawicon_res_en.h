/*
 * drawicon_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define DI_ST_CAP   "Demo of drawing icon"
