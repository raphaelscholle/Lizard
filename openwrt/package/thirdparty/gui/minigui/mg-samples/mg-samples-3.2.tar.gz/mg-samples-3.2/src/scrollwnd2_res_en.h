#define CAPTION     "Controls in a ScrollWnd"
#define BUTTON_TEXT "OK"
#define INIT        "Initializing..."
