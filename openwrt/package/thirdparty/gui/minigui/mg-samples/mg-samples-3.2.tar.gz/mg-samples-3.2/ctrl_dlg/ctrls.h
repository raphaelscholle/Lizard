
void static_demo (HWND hwnd);
void button_demo (HWND hwnd);
void menubutton_demo (HWND hwnd);
void edit_demo (HWND hwnd);
void listbox_demo (HWND hwnd);
void progressbar_demo (HWND hwnd);
void combobox_demo (HWND hwnd);
void toolbar_demo (HWND hwnd);
void trackbar_demo (HWND hwnd);

void listview_demo (HWND hwnd);
void grid_demo(HWND hwnd);
void treeview_demo (HWND hwnd);
void monthcalendar_demo (HWND hwnd);
void spinbox_demo (HWND hwnd);
void coolbar_demo (HWND hwnd);

void subclass_demo (HWND hwnd);
void timeeditor (HWND hwnd);
void newtoolbar_demo(HWND hwnd);

