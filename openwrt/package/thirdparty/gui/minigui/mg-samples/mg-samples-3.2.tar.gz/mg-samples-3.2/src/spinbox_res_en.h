#define CAPTION  "Spinbox"
