
void testPropertySheet (HWND hWnd);

