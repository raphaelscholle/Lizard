#define add                                  "Add"
#define delete_                              "Delete"
#define my_friends                           "My Friends"
