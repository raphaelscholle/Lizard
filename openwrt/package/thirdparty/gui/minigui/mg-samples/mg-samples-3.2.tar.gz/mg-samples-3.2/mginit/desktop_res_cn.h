/*
 * desktop_res_cn.h
 * GB2312 charset for Simplified Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-02-03.
 */

#define MGDT_ST_ICONMENU        ""
#define MGDT_ST_OPEN            "��"
#define MGDT_ST_ABOUT           "����"
#define MGDT_ST_ABOUTM          "����MiniGUI..."
#define MGDT_ST_REFRESH         "ˢ��"
