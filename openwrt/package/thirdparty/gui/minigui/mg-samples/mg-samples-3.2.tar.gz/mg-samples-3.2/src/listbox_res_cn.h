#define     deleting_the_files                 "ɾ���ļ�"
#define     directories                        "·��:"
#define     files_                             "�ļ�:"
#define     path_                              "��: "
#define     delete_                            "ɾ��"
#define     cancel_                            "ȡ��"
#define     deleting_files_                    "ɾ���ļ�"

