/*
 * capture_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CP_ST_CAP       "Using mouse capture demo"
#define CP_ST_PRESSED   "pressed"
