/*
 * fminigui_res_cn.h
 * GB2312 charset for Simlified Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define FM_ST_CAP   "�趯��GUI"
