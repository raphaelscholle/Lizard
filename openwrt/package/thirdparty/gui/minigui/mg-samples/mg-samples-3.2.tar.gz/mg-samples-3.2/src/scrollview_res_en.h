#define CAPTION "My Friends"
const char *people[] =
{
    "cao cao",
    "sun quan",
    "liu bei",
    "zhu ge liang",
    "guan yu",
    "pang tong",
    "si ma yu",
};
