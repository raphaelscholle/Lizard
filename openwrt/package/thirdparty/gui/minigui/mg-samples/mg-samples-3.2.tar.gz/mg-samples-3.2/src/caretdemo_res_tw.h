/*
 * caretdemo_res_en.h
 * big5 charset for Complex Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CD_ST_CAP   "���Хܨҵ{��"
