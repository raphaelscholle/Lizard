#define please_input_the_length_mm      "Please input the length(Unit: mm)"
#define equivalent_to_inches            "Equivalent to  0.00 inches"
#define please_input_the_length         "Please input the length"
#define equivalent_to_f_inches          "Equivalent to %.5f inches "
