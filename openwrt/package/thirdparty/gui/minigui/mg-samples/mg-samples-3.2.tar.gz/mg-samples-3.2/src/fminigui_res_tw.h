/*
 * fminigui_res_tw.h
 * big5 charset for Complex Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define FM_ST_CAP   "�R�ʪ�GUI"
