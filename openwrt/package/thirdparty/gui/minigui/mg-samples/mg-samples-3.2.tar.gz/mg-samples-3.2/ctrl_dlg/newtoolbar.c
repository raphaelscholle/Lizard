/*
** $Id: newtoolbar.c 434 2008-02-03 07:30:11Z mgwang $
**
** newtoolbar.c: The NewToolBar control demo program.
**
** Copyright (C) 2003 ~ 2017 FMSoft (http://www.fmsoft.cn).
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef __NOUNIX__
#include <unistd.h>
#endif
#include <sys/stat.h>
#include <sys/types.h>

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>

#ifdef _MGCTRL_NEWTOOLBAR

#ifdef _LANG_ZHCN
#include "dlgdemo_res_cn.h"
#elif defined _LANG_ZHTW
#include "dlgdemo_res_tw.h"
#else
#include "dlgdemo_res_en.h"
#endif

#define LEN_TEXT    50
#define LEN_TIP     50

#define IDC_CTRL_BUTTON       100
#define IDC_CTRL_NEWTOOLBAR_1 110
#define IDC_CTRL_NEWTOOLBAR_2 120
#define IDC_CTRL_NEWTOOLBAR_3 130
#define IDC_CTRL_NEWTOOLBAR_4 140

#define IDC_NTB_ONE           140
#define IDC_NTB_TWO           150
#define IDC_NTB_THREE         160
#define IDC_NTB_FOUR          170


static HWND hMainWnd = HWND_INVALID;
RECT rect={0,330,500,400};
static void my_hotspot_proc (HWND hwnd, int id, const RECT* cell, int x, int y)
{
        HDC hdc;
        char buff [254];

        Ping ();
        memset (buff, 0, sizeof (buff));
        hdc = GetClientDC (GetParent (hwnd));
        InvalidateRect(hwnd,&rect,TRUE);
        memset(buff,0,sizeof(buff));
        sprintf (buff, "Hotpot of button %d of NewToolBar %ld clicked.", id, GetDlgCtrlID (hwnd));
        TextOut (hdc, 0, 330, buff);
        ReleaseDC (hdc);
}

BITMAP bitmap1, bitmap2, bitmap3, bitmap4;

static void create_newtoolbars (HWND hWnd)
{
    HWND ntb1, ntb2, ntb3, ntb4;
    NTBINFO ntb_info;
    NTBITEMINFO ntbii;
    gal_pixel pixel;
    RECT hotspot = {16, 16, 32, 32};

    ntb_info.nr_cells = 4;
    ntb_info.w_cell  = 0;
    ntb_info.h_cell  = 0;
    ntb_info.nr_cols = 0;
    ntb_info.image = &bitmap1;

    ntb1 = CreateWindow (CTRL_NEWTOOLBAR,
                    "",
                    WS_CHILD | WS_VISIBLE, 
                    IDC_CTRL_NEWTOOLBAR_1,
                    0, 10, 1024, 0,
                    hWnd,
                    (DWORD) &ntb_info);
    pixel = GetPixelInBitmap (&bitmap1, 0, 0);
    SetWindowBkColor (ntb1, pixel);
    InvalidateRect (ntb1, NULL, TRUE);

    ntb_info.nr_cells = 4;
    ntb_info.w_cell  = 0;
    ntb_info.h_cell  = 0;
    ntb_info.nr_cols = 0;
    ntb_info.image = &bitmap2;
    ntb2 = CreateWindow (CTRL_NEWTOOLBAR,
                    "",
                    WS_CHILD | WS_VISIBLE | NTBS_WITHTEXT,
                    IDC_CTRL_NEWTOOLBAR_2,
                    0, 80, 1024, 0,
                    hWnd,(DWORD) &ntb_info);
    pixel = GetPixelInBitmap (&bitmap2, 0, 0);
    SetWindowBkColor (ntb2, pixel);
    InvalidateRect (ntb2, NULL, TRUE);

    ntb_info.nr_cells = 4;
    ntb_info.w_cell  = 0;
    ntb_info.h_cell  = 0;
    ntb_info.nr_cols = 0;
    ntb_info.image = &bitmap3;
    ntb3 = CreateWindow (CTRL_NEWTOOLBAR, "",
                    WS_CHILD | WS_VISIBLE
                    | NTBS_WITHTEXT | NTBS_TEXTRIGHT | NTBS_DRAWSEPARATOR,
                    IDC_CTRL_NEWTOOLBAR_3,
                    0, 170, 1024, 0,
                    hWnd,(DWORD) &ntb_info);
    pixel = GetPixelInBitmap (&bitmap3, 0, 0);
    SetWindowBkColor (ntb3, pixel);
    InvalidateRect (ntb3, NULL, TRUE);

    ntb_info.nr_cells = 4;
    ntb_info.w_cell  = 0;
    ntb_info.h_cell  = 0;
    ntb_info.nr_cols = 0;
    ntb_info.image = &bitmap4;
    ntb4 = CreateWindow (CTRL_NEWTOOLBAR, "",
                    WS_CHILD | WS_VISIBLE | NTBS_WITHTEXT | NTBS_TEXTRIGHT | NTBS_DRAWSTATES,
                    IDC_CTRL_NEWTOOLBAR_4,
                    0, 245, 1024, 0,
                    hWnd,(DWORD) &ntb_info);
    pixel = GetPixelInBitmap (&bitmap4, 0, 0);
    SetWindowBkColor (ntb4, pixel);
    InvalidateRect (ntb4, NULL, TRUE);

    memset (&ntbii, 0, sizeof (ntbii));
    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_ONE;
    ntbii.bmp_cell = 0;
    SendMessage (ntb1, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_TWO;
    ntbii.bmp_cell = 2;
    SendMessage(ntb1, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON | NTBIF_DISABLED;
    ntbii.id = IDC_NTB_THREE;
    ntbii.bmp_cell = 1;
    SendMessage (ntb1, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_SEPARATOR;
    ntbii.id = 0;
    ntbii.bmp_cell = 0;
    ntbii.text = NULL;
    SendMessage (ntb1, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_HOTSPOTBUTTON;
    ntbii.id = IDC_NTB_FOUR;
    ntbii.bmp_cell = 3;
    ntbii.rc_hotspot = hotspot;
    ntbii.hotspot_proc = my_hotspot_proc;
    SendMessage (ntb1, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    memset (&ntbii, 0, sizeof (ntbii));
    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_ONE;
    ntbii.bmp_cell = 0;
    ntbii.text = Up;
    SendMessage (ntb2, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_TWO;
    ntbii.bmp_cell = 2;
    ntbii.text = Prev;
    SendMessage (ntb2, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON | NTBIF_DISABLED;
    ntbii.id = IDC_NTB_THREE;
    ntbii.bmp_cell = 1;
    ntbii.text = Next;
    SendMessage (ntb2, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_SEPARATOR;
    ntbii.id = 0;
    ntbii.bmp_cell = 0;
    ntbii.text = NULL;
    SendMessage (ntb2, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_HOTSPOTBUTTON;
    ntbii.id = IDC_NTB_FOUR;
    ntbii.bmp_cell = 3;
    ntbii.rc_hotspot = hotspot;
    ntbii.hotspot_proc = my_hotspot_proc;
    ntbii.text = Menu;
    SendMessage (ntb2, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    memset (&ntbii, 0, sizeof (ntbii));
    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_ONE;
    ntbii.bmp_cell = 0;
    ntbii.text = Up;
    SendMessage (ntb3, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_TWO;
    ntbii.bmp_cell = 1;
    ntbii.text = Prev;
    SendMessage (ntb3, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_THREE;
    ntbii.bmp_cell = 2;
    ntbii.text = Next;
    SendMessage (ntb3, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_SEPARATOR;
    ntbii.id = 0;
    ntbii.bmp_cell = 0;
    ntbii.text = NULL;
    SendMessage (ntb3, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_HOTSPOTBUTTON | NTBIF_DISABLED;
    ntbii.id = IDC_NTB_FOUR;
    ntbii.bmp_cell = 3;
    ntbii.rc_hotspot = hotspot;
    ntbii.hotspot_proc = my_hotspot_proc;
    ntbii.text = Menu;
    SendMessage (ntb3, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    memset (&ntbii, 0, sizeof (ntbii));
    ntbii.flags = NTBIF_PUSHBUTTON | NTBIF_DISABLED;
    ntbii.id = IDC_NTB_ONE;
    ntbii.bmp_cell = 0;
    ntbii.text = Up;
    SendMessage (ntb4, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_TWO;
    ntbii.bmp_cell = 1;
    ntbii.text = Prev;
    SendMessage (ntb4, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_PUSHBUTTON;
    ntbii.id = IDC_NTB_THREE;
    ntbii.bmp_cell = 2;
    ntbii.text = Next;
    SendMessage (ntb4, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_SEPARATOR;
    ntbii.id = 0;
    ntbii.bmp_cell = 0;
    ntbii.text = NULL;
    SendMessage (ntb4, NTBM_ADDITEM, 0, (LPARAM)&ntbii);

    ntbii.flags = NTBIF_HOTSPOTBUTTON;
    ntbii.id = IDC_NTB_FOUR;
    ntbii.bmp_cell = 3;
    ntbii.rc_hotspot = hotspot;
    ntbii.hotspot_proc = my_hotspot_proc;
    ntbii.text = Menu;
    SendMessage (ntb4, NTBM_ADDITEM, 0, (LPARAM)&ntbii);
}

static LRESULT ControlTestWinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
    case MSG_CREATE:
        if (LoadBitmap (HDC_SCREEN, &bitmap1, "res/new1.jpg"))
            return -1;

        if (LoadBitmap (HDC_SCREEN, &bitmap2, "res/new4.jpg"))
            return -1;

        if (LoadBitmap (HDC_SCREEN, &bitmap3, "res/new3.jpg"))
            return -1;

        if (LoadBitmap (HDC_SCREEN, &bitmap4, "res/new2.jpg"))
            return -1;

        CreateWindow (CTRL_BUTTON, Close,
                        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE, IDC_CTRL_BUTTON, 
                        400, 320, 60, 25, hWnd,0);
        create_newtoolbars (hWnd);
        break;

    case MSG_COMMAND:
    {
        int id = LOWORD(wParam);
        int code = HIWORD(wParam);
        HDC hdc;
        char buff [254];

        if (wParam == IDC_CTRL_BUTTON) {
            PostMessage (hWnd, MSG_CLOSE, 0, 0);
            break;
        }

        memset (buff, 0, sizeof (buff));
        hdc = GetClientDC (hWnd);

        InvalidateRect(hWnd,&rect,TRUE);
        memset(buff,0,sizeof(buff));
        sprintf (buff, "Button %d of NewToolBar %d clicked.", code, id);
        TextOut (hdc, 0, 330, buff);
        ReleaseDC (hdc);
        break;
    }

    case MSG_DESTROY:
        UnloadBitmap (&bitmap1);
        UnloadBitmap (&bitmap2);
        UnloadBitmap (&bitmap3);
        UnloadBitmap (&bitmap4);
        DestroyAllControls (hWnd);
        hMainWnd = HWND_INVALID;
	return 0;

    case MSG_CLOSE:
        DestroyMainWindow (hWnd);
        MainWindowCleanup (hWnd);
        return 0;
    }

    return DefaultMainWinProc (hWnd, message, wParam, lParam);
}

static void InitCreateInfo (PMAINWINCREATE pCreateInfo)
{
    pCreateInfo->dwStyle = WS_CAPTION | WS_BORDER | WS_VISIBLE;
    pCreateInfo->dwExStyle = WS_EX_NONE;
    pCreateInfo->spCaption = NewToolBar_controls;
    pCreateInfo->hMenu = 0;
    pCreateInfo->hCursor = GetSystemCursor(0);
    pCreateInfo->hIcon = 0;
    pCreateInfo->MainWindowProc = ControlTestWinProc;
    pCreateInfo->lx = 0;
    pCreateInfo->ty = 0;
    pCreateInfo->rx = 480;
    pCreateInfo->by = 380;
    pCreateInfo->iBkColor = PIXEL_lightgray;
    pCreateInfo->dwAddData = 0;
    pCreateInfo->hHosting = HWND_DESKTOP;
}

void newtoolbar_demo (HWND hwnd)
{
    MAINWINCREATE CreateInfo;

    if (hMainWnd != HWND_INVALID) {
        ShowWindow (hMainWnd, SW_SHOWNORMAL);
        return;
    }

    InitCreateInfo (&CreateInfo);
    CreateInfo.hHosting = hwnd;

    hMainWnd = CreateMainWindow (&CreateInfo);
}

#else

void newtoolbar_demo (HWND hwnd)
{
    MessageBox (hwnd, "WARNING", "Please enable NEWTOOLBAR control support in MiniGUI.", MB_OK);
}

#endif /* _MGCTRL_NEWTOOLBAR */

