/*
 * gridview_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define GV_ST_CAP       "GridView Controler"
#define GV_ST_CHINESE   "Chinese"
#define GV_ST_MATH      "Math"
#define GV_ST_ENGLISH   "English"
#define GV_ST_TOTAL     "Total"
#define GV_ST_STUD1     "Rose"
#define GV_ST_STUD2     "Joan"
#define GV_ST_STUD3     "Rob"
#define GV_ST_STUD4     "John"
#define GV_ST_AVERAGE   "Average"

