/*
 * desktop_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-02-03.
 */

#define MGDT_ST_ICONMENU        ""
#define MGDT_ST_OPEN            "Open"
#define MGDT_ST_ABOUT           "About"
#define MGDT_ST_ABOUTM          "About MiniGUI..."
#define MGDT_ST_REFRESH         "Refresh"
