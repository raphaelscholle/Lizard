#define CAPTION "StretchBlt demo"
