/*
 * same_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-02-02.
 */

#define SM_ST_SETSCORE      "Score :"
#define SM_ST_ENDGAME       "End of Game! \nYour Score:"
#define SM_ST_SAMEGAME      "The Same Game"
#define SM_ST_GAME          "Game"
#define SM_ST_NEWGAME       "New Game"
#define SM_ST_SCORE         "Scores..."
#define SM_ST_EXIT          "Exit"
#define SM_ST_SET           "Settings"
#define SM_ST_PREF          "Preferences..."
#define SM_ST_ABOUT         "About"
#define SM_ST_ABOUTTHIS     "About Same Game..."
#define SM_ST_SCENARIO      "Scenario: "
#define SM_ST_MNB           "<scenario>"
#define SM_ST_SAME          "Same"
#define SM_ST_QUIT          "Are you sure to quit?"
