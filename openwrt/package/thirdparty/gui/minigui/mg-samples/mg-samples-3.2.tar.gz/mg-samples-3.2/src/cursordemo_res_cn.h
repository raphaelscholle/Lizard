/*
 * cursordemo_res_cn.h
 * GB2312 charset for Simlified Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CSD_ST_CAP  "�������"
