/*
 * createicon_res_tw.h
 * big5 charset for Complex Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CI_ST_CAP   "�ЫعϼХܨҵ{��"
