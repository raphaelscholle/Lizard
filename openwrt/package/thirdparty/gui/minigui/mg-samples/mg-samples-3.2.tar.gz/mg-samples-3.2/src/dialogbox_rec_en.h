#define the_system_is_initializing        "The system is initializing"
#define Initializing                                "Initializing..."
#define OK                                          "OK"
