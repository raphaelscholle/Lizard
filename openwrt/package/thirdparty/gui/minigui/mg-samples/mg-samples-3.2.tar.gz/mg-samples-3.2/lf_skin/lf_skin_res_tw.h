
static char* g_pTitleButton = "換膚" ;

static char* g_pHelpList    = "列表" ;

static char* g_pHelpInfo    = "信息" ;

static char* g_pMainTitle   = "媒體播放器" ;

static char* g_pHelpTitle   = "幫助" ;

static char* help_info_text = "該媒體播放器是以MiniGUI Versi\n"
                              "on 3.0為平台開發的應用程序\n"
                              "版權所有 2003-2008 北京飛漫軟\n"
                              "件技術有限公司\n";

static TVITEMINFO ListViewInfo = 
{
    "幫助" 
};

static const char *chapter[] = 
{
    "關於播放",
    "關於停止",
    "關於音量",
    "添加播放文件",
};

static const char *section[] =
{
    "按開始或暫停按鈕",
    "按停止按鈕",
    "滑動音量條",
    "按添加文件按鈕"
};
