/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __OEM_H__
#define __OEM_H__

#include <oemcommon.h>

#include <oemplatform.h>

#endif  /* __OEM_H__ */
