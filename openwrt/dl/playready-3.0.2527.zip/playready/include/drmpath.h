#ifndef __DRMPATH_H__
#define __DRMPATH_H__

//You can modify the path in this file, but do not change the order of lines

//define path for license
#define PLAYREADY_TMPFILE_DIR "/etc/drm/"

//define path for certificates
#define PLAYREADY_CERT_DIR    "/etc/playready/"

#endif